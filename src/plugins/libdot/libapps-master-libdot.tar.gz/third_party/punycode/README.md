This is a port of punycode.js to the libdot framework.

Upstream details can be found in the METADATA file.

Licensing details can be found in LICENSE.md.

For details on the API, consult the upstream site.  The main functions are
available under the `lib.punycode` namespace.

To pull in a newer version, just run `./update`.
