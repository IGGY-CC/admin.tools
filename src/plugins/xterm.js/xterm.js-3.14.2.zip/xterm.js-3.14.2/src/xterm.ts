/**
 * Copyright (c) 2017 The xterm.js authors. All rights reserved.
 * @license MIT
 *
 * This file is the entry point for browserify.
 */

import { Terminal } from './public/Terminal';

module.exports = Terminal;
