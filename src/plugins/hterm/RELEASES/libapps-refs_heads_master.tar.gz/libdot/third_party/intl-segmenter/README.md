Polyfill from https://github.com/tc39/proposal-intl-segmenter
