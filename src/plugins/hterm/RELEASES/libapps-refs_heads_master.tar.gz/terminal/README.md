# chrome://terminal

The chrome://terminal System Web App is the default
[Chrome OS Linux (crostini)](https://chromium.googlesource.com/chromiumos/docs/+/master/containers_and_vms.md)
terminal.

# Contact

The [chromium-hterm mailing list] can be used to contact other users and
developers for questions.

[chromium-hterm mailing list]: https://groups.google.com/a/chromium.org/forum/?fromgroups#!forum/chromium-hterm
