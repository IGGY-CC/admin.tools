/* A stub header that some sources include unconditionally. */
